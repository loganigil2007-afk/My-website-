import type { Product, ShopConfig } from './types';
import oneKImage from './assets/gallery/file_00000000e330820bb58e7c399bf7684b copy.png';
import twoKImage from './assets/gallery/IMG-20261020-WA0059 copy.jpg';
import fiveKImage from './assets/gallery/IMG-20261020-WA0060 copy.jpg';
import tenKImage from './assets/gallery/motion_photo_7578446050472871929 copy.jpg';

// ============================================================
//  SHOP CONFIGURATION
//  Update these values as the owner provides real information.
//  Leave a field as `null` until it is confirmed — the UI will
//  hide it gracefully.
// ============================================================

export const shopConfig: ShopConfig = {
  brandName: "ORCA'S",
  // WhatsApp number in international format, digits only, no + or spaces.
  whatsappNumber: '919363926946',
  phone: '9363926946',
  secondaryPhone: '8825706091',
  address: null,
  businessHours: null,
  mapsLink: null,
  instagram: 'https://www.instagram.com/orcasbrand?psln=NHViYzMzYW85OGV0',
  facebook: null,
  // Festival / seasonal announcement bar text. Leave null to hide the bar.
  announcement: null,
};

// ============================================================
//  PRODUCT CATALOGUE — exactly four Garland products.
//  Set `price` to a number once the owner provides it.
//  Set `image` to a URL/path once the photo is supplied.
//  Set `available` to true/false once confirmed.
// ============================================================

export const products: Product[] = [
  {
    id: '1k-garland',
    name: '1K Garland',
    price: null,
    image: oneKImage,
    available: null,
  },
  {
    id: '2k-garland',
    name: '2K Garland',
    price: null,
    image: twoKImage,
    available: null,
  },
  {
    id: '5k-garland',
    name: '5K Garland',
    price: null,
    image: fiveKImage,
    available: null,
  },
  {
    id: '10k-garland',
    name: '10K Garland',
    price: null,
    image: tenKImage,
    available: null,
  },
];

// Hero background — golden fireworks over night sky (Pexels, license-free).
export const heroImage =
  'https://images.pexels.com/photos/33672884/pexels-photo-33672884.jpeg?auto=compress&cs=tinysrgb&w=1920';

export const aboutImage =
  'https://images.pexels.com/photos/12745603/pexels-photo-12745603.jpeg?auto=compress&cs=tinysrgb&w=1200';
