import type { CartItem } from './types';
import { shopConfig } from './config';

export function buildWhatsAppUrl(message: string): string {
  const number = shopConfig.whatsappNumber;
  if (!number) return '#';
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${number}?text=${encoded}`;
}

export function buildProductEnquiry(productName: string, quantity: number): string {
  return (
    `Hello ${shopConfig.brandName} Fireworks! I would like to enquire about the following products:\n` +
    `\n1. ${productName} — Quantity: ${quantity}\n` +
    `\nPlease share the current price, availability, and applicable purchase conditions. Thank you.`
  );
}

export function buildCartEnquiry(items: CartItem[], pricesConfigured: boolean): string {
  if (items.length === 0) return '';
  const lines = items.map(
    (item, idx) => `${idx + 1}. ${item.name} — Quantity: ${item.quantity}`,
  );
  const intro = pricesConfigured
    ? `Hello ${shopConfig.brandName} Fireworks! I would like to place an enquiry for the following products:`
    : `Hello ${shopConfig.brandName} Fireworks! I would like to request a price quotation for the following products:`;
  return `${intro}\n\n${lines.join('\n')}\n\nPlease share the current price, availability, and applicable purchase conditions. Thank you.`;
}

export function buildGeneralEnquiry(): string {
  return `Hello ${shopConfig.brandName}! I visited your website and would like to enquire about your products. Please share the details. Thank you.`;
}
