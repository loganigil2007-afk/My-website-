export interface Product {
  id: string;
  name: string;
  price: number | null;
  image: string | null;
  available: boolean | null;
}

export interface CartItem {
  productId: string;
  name: string;
  quantity: number;
}

export interface ShopConfig {
  brandName: string;
  whatsappNumber: string | null;
  phone: string | null;
  secondaryPhone: string | null;
  address: string | null;
  businessHours: string | null;
  mapsLink: string | null;
  instagram: string | null;
  facebook: string | null;
  announcement: string | null;
}
