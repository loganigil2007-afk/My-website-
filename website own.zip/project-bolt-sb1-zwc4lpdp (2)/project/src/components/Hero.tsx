import { ArrowDown, MessageCircle } from 'lucide-react';
import { Particles } from './Particles';
import { Logo } from './Logo';
import { heroImage, shopConfig } from '../config';
import { buildGeneralEnquiry, buildWhatsAppUrl } from '../whatsapp';

export function Hero() {
  const scrollToCollection = () => {
    document.querySelector('#collection')?.scrollIntoView({ behavior: 'smooth' });
  };

  const hasWhatsApp = shopConfig.whatsappNumber !== null;
  const waUrl = hasWhatsApp ? buildWhatsAppUrl(buildGeneralEnquiry()) : '#';

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Golden fireworks illuminating the night sky"
          className="h-full w-full object-cover opacity-40"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#080808]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/60" />
      </div>

      <Particles count={40} />

      {/* Twinkling stars */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        {Array.from({ length: 50 }).map((_, i) => (
          <span
            key={i}
            className="animate-twinkle absolute rounded-full bg-[#F5E6A8]"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 80}%`,
              width: `${1 + Math.random() * 2}px`,
              height: `${1 + Math.random() * 2}px`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center px-5 text-center">
        <div className="animate-float mb-8">
          <Logo className="h-40 w-40 scale-110 sm:h-48 sm:w-48" />
        </div>

        <p className="animate-fade-in mb-4 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">
          {shopConfig.brandName} Fireworks
        </p>

        <h1 className="animate-fade-in-up font-serif text-4xl font-bold leading-tight text-white sm:text-5xl md:text-6xl lg:text-7xl">
          MAKE EVERY CELEBRATION
          <br />
          <span className="text-gradient-gold">ICONIC.</span>
        </h1>

        <p className="animate-fade-in-up mt-6 max-w-xl text-base text-neutral-300 sm:text-lg" style={{ animationDelay: '0.2s' }}>
          Celebrate every special moment with {shopConfig.brandName} Fireworks.
        </p>

        <div className="animate-fade-in-up mt-10 flex flex-col gap-4 sm:flex-row" style={{ animationDelay: '0.4s' }}>
          <button
            onClick={scrollToCollection}
            className="group relative overflow-hidden rounded-full bg-gold-gradient px-8 py-4 text-sm font-semibold uppercase tracking-widest text-black transition-all hover:gold-glow-strong"
          >
            <span className="relative z-10 flex items-center gap-2">
              Explore Our Collection
              <ArrowDown className="h-4 w-4 transition-transform group-hover:translate-y-1" />
            </span>
          </button>

          <a
            href={waUrl}
            target={hasWhatsApp ? '_blank' : undefined}
            rel={hasWhatsApp ? 'noopener noreferrer' : undefined}
            className={`flex items-center justify-center gap-2 rounded-full border border-[#D4AF37]/40 px-8 py-4 text-sm font-semibold uppercase tracking-widest text-[#F5E6A8] transition-all hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 ${
              !hasWhatsApp ? 'pointer-events-none opacity-40' : ''
            }`}
          >
            <MessageCircle className="h-4 w-4" />
            Enquire on WhatsApp
          </a>
        </div>

        {!hasWhatsApp && (
          <p className="mt-4 text-xs text-neutral-500">
            WhatsApp enquiries will be available once the shop number is configured.
          </p>
        )}
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="flex h-10 w-6 items-start justify-center rounded-full border border-[#D4AF37]/30 p-1.5">
          <span className="h-2 w-1 animate-bounce rounded-full bg-[#D4AF37]" />
        </div>
      </div>
    </section>
  );
}
