import { useMemo } from 'react';

interface Particle {
  left: number;
  delay: number;
  duration: number;
  size: number;
}

export function Particles({ count = 30 }: { count?: number }) {
  const particles = useMemo<Particle[]>(
    () =>
      Array.from({ length: count }, () => ({
        left: Math.random() * 100,
        delay: Math.random() * 8,
        duration: 6 + Math.random() * 6,
        size: 1 + Math.random() * 2.5,
      })),
    [count],
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {particles.map((p, i) => (
        <span
          key={i}
          className="animate-particle absolute bottom-0 rounded-full bg-gradient-to-b from-[#F5E6A8] to-[#D4AF37]"
          style={{
            left: `${p.left}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            boxShadow: '0 0 6px rgba(212, 175, 55, 0.6)',
          }}
        />
      ))}
    </div>
  );
}
