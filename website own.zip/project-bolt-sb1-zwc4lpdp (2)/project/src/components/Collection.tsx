import { ProductCard } from './ProductCard';
import type { Product, CartItem } from '../types';

interface CollectionProps {
  products: Product[];
  onAddToCart: (productId: string, name: string, quantity: number) => void;
}

export function Collection({ products, onAddToCart }: CollectionProps) {
  return (
    <section id="collection" className="relative overflow-hidden bg-[#080808] py-24 sm:py-32">
      {/* Subtle background glow */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[400px] w-[600px] -translate-x-1/2 rounded-full bg-[#D4AF37]/5 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        {/* Section header */}
        <div className="mb-16 text-center">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">
            Premium Selection
          </p>
          <h2 className="font-serif text-3xl font-bold text-gradient-gold sm:text-4xl md:text-5xl">
            OUR GARLAND COLLECTION
          </h2>
          <div className="mx-auto mt-6 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-[#D4AF37]" />
            <span className="h-1.5 w-1.5 rotate-45 bg-[#D4AF37]" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-[#D4AF37]" />
          </div>
          <p className="mx-auto mt-6 max-w-2xl text-sm text-neutral-400 sm:text-base">
            Four signature garland crackers, crafted for grand celebrations.
            Contact us for current pricing and availability.
          </p>
        </div>

        {/* Product grid — 2 cols on mobile, 4 on desktop */}
        <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
          ))}
        </div>
      </div>
    </section>
  );
}

// Re-export for convenience
export type { Product, CartItem };
