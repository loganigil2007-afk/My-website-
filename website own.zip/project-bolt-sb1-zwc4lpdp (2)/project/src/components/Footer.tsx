import { Instagram, MessageCircle, Phone } from 'lucide-react';
import { Logo } from './Logo';
import { shopConfig } from '../config';
import { buildGeneralEnquiry, buildWhatsAppUrl } from '../whatsapp';

const quickLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Collection', href: '#collection' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
  { label: 'Domain Setup', href: '#domain-setup' },
];

export function Footer() {
  const year = new Date().getFullYear();
  const waUrl = buildWhatsAppUrl(buildGeneralEnquiry());

  const handleNav = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative border-t border-[#D4AF37]/20 bg-black">
      <div className="h-px w-full bg-gradient-to-r from-transparent via-[#D4AF37]/40 to-transparent" />

      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-neutral-500">
              Premium fireworks for every celebration. Make every moment iconic with {shopConfig.brandName}.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.3em] text-[#D4AF37]">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); handleNav(link.href); }}
                    className="text-sm text-neutral-400 transition-colors hover:text-[#F5E6A8]"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.3em] text-[#D4AF37]">
              Contact
            </h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a href={`tel:${shopConfig.phone}`} className="font-display inline-flex items-center gap-2 text-sm text-neutral-400 transition-colors hover:text-[#F5E6A8]">
                  <Phone className="h-4 w-4 text-[#D4AF37]" />
                  {shopConfig.phone}
                </a>
              </li>
              <li>
                <a href={`tel:${shopConfig.secondaryPhone}`} className="font-display inline-flex items-center gap-2 text-sm text-neutral-400 transition-colors hover:text-[#F5E6A8]">
                  <Phone className="h-4 w-4 text-[#D4AF37]" />
                  {shopConfig.secondaryPhone}
                </a>
              </li>
              <li>
                <a href={waUrl} target="_blank" rel="noopener noreferrer" className="font-display inline-flex items-center gap-2 text-sm text-neutral-400 transition-colors hover:text-[#F5E6A8]">
                  <MessageCircle className="h-4 w-4 text-[#25D366]" />
                  WhatsApp Enquiry
                </a>
              </li>
              <li>
                <a href={shopConfig.instagram ?? '#'} target="_blank" rel="noopener noreferrer" className="font-display inline-flex items-center gap-2 text-sm text-neutral-400 transition-colors hover:text-[#F5E6A8]">
                  <Instagram className="h-4 w-4 text-[#D4AF37]" />
                  @orcasbrand
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="my-8 h-px w-full bg-gradient-to-r from-transparent via-[#D4AF37]/20 to-transparent" />

        <div className="flex flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-neutral-600">© ORCA'S. All rights reserved.</p>
          <p className="text-xs text-neutral-600">
            Fireworks sold subject to applicable Indian laws &amp; safety regulations.
          </p>
        </div>
      </div>
    </footer>
  );
}
