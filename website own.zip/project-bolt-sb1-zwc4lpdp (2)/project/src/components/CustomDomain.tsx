import { useState } from 'react';
import { ArrowRight, Check, Copy, Globe2, LockKeyhole, ShieldCheck } from 'lucide-react';

const dnsPlaceholders = [
  { label: 'Record type', value: 'A / CNAME — provided by your hosting service' },
  { label: 'Host / name', value: 'your-domain.com or www' },
  { label: 'Target / value', value: 'The exact destination value provided by your host' },
  { label: 'TTL', value: 'Automatic or the value recommended by your host' },
];

export function CustomDomain() {
  const [domain, setDomain] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!domain.trim() || !confirmed) return;
    setSubmitted(true);
  };

  const copyDomain = async () => {
    if (!domain.trim() || !navigator.clipboard) return;
    await navigator.clipboard.writeText(domain.trim());
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <section id="domain-setup" className="relative overflow-hidden bg-[#0a0a0a] py-24 sm:py-32">
      <div className="pointer-events-none absolute left-0 top-1/3 h-[320px] w-[420px] rounded-full bg-[#D4AF37]/5 blur-[110px]" />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">
            Website Setup
          </p>
          <h2 className="font-serif text-3xl font-bold text-gradient-gold sm:text-4xl md:text-5xl">
            CONNECT YOUR DOMAIN
          </h2>
          <div className="mx-auto mt-6 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-[#D4AF37]" />
            <span className="h-1.5 w-1.5 rotate-45 bg-[#D4AF37]" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-[#D4AF37]" />
          </div>
          <p className="mt-6 text-sm leading-relaxed text-neutral-400 sm:text-base">
            Connect a domain you already own to give your ORCA'S website a memorable home. This guide prepares the details only — it never changes your domain or DNS settings automatically.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="rounded-2xl border border-[#D4AF37]/20 bg-[#111111] p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full border border-[#D4AF37]/30 text-[#D4AF37]">
                <Globe2 className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.25em] text-[#D4AF37]">Your domain</p>
                <h3 className="mt-1 font-serif text-2xl font-bold text-[#F5E6A8]">Start here</h3>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="mt-8">
              <label htmlFor="custom-domain" className="text-xs font-semibold uppercase tracking-[0.2em] text-neutral-400">
                Domain name
              </label>
              <div className="mt-3 flex rounded-xl border border-[#D4AF37]/30 bg-black focus-within:border-[#D4AF37]">
                <input
                  id="custom-domain"
                  type="text"
                  value={domain}
                  onChange={(event) => { setDomain(event.target.value); setSubmitted(false); }}
                  placeholder="orcasbrand.in"
                  className="min-w-0 flex-1 bg-transparent px-4 py-3 text-sm text-white outline-none placeholder:text-neutral-600"
                  autoComplete="url"
                />
                <button
                  type="button"
                  onClick={copyDomain}
                  disabled={!domain.trim()}
                  className="px-3 text-neutral-500 transition-colors hover:text-[#F5E6A8] disabled:cursor-not-allowed disabled:opacity-30"
                  aria-label="Copy domain name"
                >
                  {copied ? <Check className="h-4 w-4 text-[#D4AF37]" /> : <Copy className="h-4 w-4" />}
                </button>
              </div>

              <label className="mt-5 flex cursor-pointer items-start gap-3 text-sm leading-relaxed text-neutral-400">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(event) => setConfirmed(event.target.checked)}
                  className="mt-1 h-4 w-4 accent-[#D4AF37]"
                />
                <span>I understand that DNS changes require my confirmation and will be made manually with my domain provider.</span>
              </label>

              <button
                type="submit"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient px-5 py-3 text-xs font-bold uppercase tracking-[0.16em] text-black transition-all hover:gold-glow-strong disabled:cursor-not-allowed disabled:opacity-40"
                disabled={!domain.trim() || !confirmed}
              >
                Prepare Connection Steps <ArrowRight className="h-4 w-4" />
              </button>
            </form>

            {submitted && (
              <div className="mt-5 rounded-xl border border-[#D4AF37]/25 bg-[#D4AF37]/5 p-4 text-sm leading-relaxed text-[#F5E6A8]" role="status">
                <div className="flex items-center gap-2 font-semibold">
                  <ShieldCheck className="h-4 w-4" />
                  Ready for manual setup
                </div>
                <p className="mt-2 text-xs text-neutral-400">
                  No changes were made. Use the DNS checklist beside this form with your domain provider, then verify the connection here or in your hosting dashboard.
                </p>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-[#D4AF37]/20 bg-gradient-to-b from-[#111111] to-[#080808] p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <LockKeyhole className="h-5 w-5 text-[#D4AF37]" />
              <h3 className="font-serif text-2xl font-bold text-[#F5E6A8]">DNS connection checklist</h3>
            </div>

            <ol className="mt-7 space-y-5">
              <li className="flex gap-4">
                <span className="font-display flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#D4AF37]/30 text-sm font-bold text-[#D4AF37]">1</span>
                <div>
                  <h4 className="font-semibold text-white">Open your domain provider</h4>
                  <p className="mt-1 text-sm leading-relaxed text-neutral-400">Sign in where you purchased the domain and open its DNS or DNS records area.</p>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="font-display flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#D4AF37]/30 text-sm font-bold text-[#D4AF37]">2</span>
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-white">Add the values from your host</h4>
                  <p className="mt-1 text-sm leading-relaxed text-neutral-400">Create the record type and enter the exact values your hosting service gives you. Do not guess these values.</p>
                  <div className="mt-3 space-y-2 rounded-xl border border-[#D4AF37]/10 bg-black/40 p-3">
                    {dnsPlaceholders.map((record) => (
                      <div key={record.label} className="flex flex-col gap-1 border-b border-white/5 pb-2 last:border-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
                        <span className="text-xs uppercase tracking-wider text-neutral-500">{record.label}</span>
                        <code className="text-xs text-[#F5E6A8] sm:text-right">{record.value}</code>
                      </div>
                    ))}
                  </div>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="font-display flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#D4AF37]/30 text-sm font-bold text-[#D4AF37]">3</span>
                <div>
                  <h4 className="font-semibold text-white">Save and wait for propagation</h4>
                  <p className="mt-1 text-sm leading-relaxed text-neutral-400">Save the records, then allow time for DNS changes to spread. Timing depends on your provider.</p>
                </div>
              </li>
              <li className="flex gap-4">
                <span className="font-display flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#D4AF37]/30 text-sm font-bold text-[#D4AF37]">4</span>
                <div>
                  <h4 className="font-semibold text-white">Verify and enable HTTPS</h4>
                  <p className="mt-1 text-sm leading-relaxed text-neutral-400">Open the domain connection screen in your hosting dashboard, choose verify, and wait for the secure HTTPS certificate to become active.</p>
                </div>
              </li>
            </ol>

            <div className="mt-7 flex gap-3 rounded-xl border border-[#D4AF37]/15 bg-[#D4AF37]/5 p-4">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#D4AF37]" />
              <p className="text-xs leading-relaxed text-neutral-400">Only proceed when the displayed domain and DNS values are correct. Ask for confirmation before saving any DNS changes with your provider.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
