import logoImage from './IMG_20261021_075823.jpg';

interface LogoProps {
  className?: string;
  showText?: boolean;
  textClassName?: string;
}

export function Logo({ className = '' }: LogoProps) {
  return (
    <div
      className={`flex aspect-square h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-[#D4AF37]/70 bg-white p-1 shadow-[0_0_14px_rgba(212,175,55,0.18)] sm:h-14 sm:w-14 ${className}`}
    >
      <img
        src={logoImage}
        alt="ORCA'S Fireworks"
        className="h-full w-full object-contain"
      />
    </div>
  );
}
