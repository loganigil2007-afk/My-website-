import { useState } from 'react';
import { MessageCircle, Plus, Minus, ShoppingCart, ImageOff, Check, X } from 'lucide-react';
import type { Product } from '../types';
import { shopConfig } from '../config';
import { buildProductEnquiry, buildWhatsAppUrl } from '../whatsapp';

interface ProductCardProps {
  product: Product;
  onAddToCart: (productId: string, name: string, quantity: number) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [qty, setQty] = useState(1);
  const hasWhatsApp = shopConfig.whatsappNumber !== null;
  const hasPrice = product.price !== null;
  const hasImage = product.image !== null;
  const availabilityKnown = product.available !== null;

  const enquiryUrl = hasWhatsApp
    ? buildWhatsAppUrl(buildProductEnquiry(product.name, qty))
    : '#';

  const handleAdd = () => onAddToCart(product.id, product.name, qty);

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-[#D4AF37]/20 bg-gradient-to-b from-[#111111] to-[#080808] transition-all duration-500 hover:border-[#D4AF37]/50 hover:gold-glow">
      {/* Image area */}
      <div className="relative aspect-square overflow-hidden bg-black">
        {hasImage ? (
          <img
            src={product.image!}
            alt={product.name}
            className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-3">
            {/* Decorative gold frame placeholder */}
            <div className="absolute inset-4 rounded-xl border border-[#D4AF37]/15" />
            <div className="absolute inset-8 rounded-lg border border-[#D4AF37]/10" />
            <ImageOff className="h-8 w-8 text-[#D4AF37]/30" />
            <p className="text-xs uppercase tracking-widest text-neutral-600">
              Photo Pending
            </p>
          </div>
        )}

        {/* Availability badge */}
        {availabilityKnown && (
          <div
            className={`absolute right-3 top-3 flex items-center gap-1 rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-wider ${
              product.available
                ? 'border border-[#D4AF37]/40 bg-black/70 text-[#F5E6A8]'
                : 'border border-red-500/40 bg-black/70 text-red-400'
            }`}
          >
            {product.available ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
            {product.available ? 'In Stock' : 'Sold Out'}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-tight tracking-wide text-[#F5E6A8] transition-colors duration-300 group-hover:text-[#D4AF37] sm:text-xl md:text-2xl">
          {product.name}
        </h3>

        {/* Price */}
        <div className="mt-2 min-h-[28px]">
          {hasPrice ? (
            <p className="font-display text-lg font-bold tracking-wide text-gradient-gold">
              ₹{product.price!.toLocaleString('en-IN')}
            </p>
          ) : (
            <p className="text-xs uppercase tracking-widest text-neutral-500">
              Price on Enquiry
            </p>
          )}
        </div>

        {/* Quantity selector */}
        <div className="mt-4 flex items-center gap-3">
          <span className="text-xs uppercase tracking-widest text-neutral-400">Qty</span>
          <div className="flex items-center rounded-full border border-[#D4AF37]/20">
            <button
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="flex h-8 w-8 items-center justify-center text-[#F5E6A8] transition-colors hover:bg-[#D4AF37]/10"
              aria-label={`Decrease quantity of ${product.name}`}
              disabled={qty <= 1}
            >
              <Minus className="h-3.5 w-3.5" />
            </button>
            <span className="font-display w-8 text-center text-sm font-bold text-white">{qty}</span>
            <button
              onClick={() => setQty((q) => Math.min(99, q + 1))}
              className="flex h-8 w-8 items-center justify-center text-[#F5E6A8] transition-colors hover:bg-[#D4AF37]/10"
              aria-label={`Increase quantity of ${product.name}`}
            >
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-5 flex flex-1 flex-col justify-end gap-2.5">
          <button
            onClick={handleAdd}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-[#D4AF37]/30 py-3 text-xs font-semibold uppercase tracking-widest text-[#F5E6A8] transition-all hover:border-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <ShoppingCart className="h-4 w-4" />
            Add to Cart
          </button>

          <a
            href={enquiryUrl}
            target={hasWhatsApp ? '_blank' : undefined}
            rel={hasWhatsApp ? 'noopener noreferrer' : undefined}
            className={`flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient py-3 text-xs font-bold uppercase tracking-widest text-black transition-all hover:gold-glow-strong ${
              !hasWhatsApp ? 'pointer-events-none opacity-40' : ''
            }`}
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp Enquiry
          </a>
        </div>
      </div>

      {/* Top corner accent */}
      <div className="pointer-events-none absolute left-0 top-0 h-12 w-12 border-l border-t border-[#D4AF37]/30 transition-all duration-500 group-hover:h-16 group-hover:w-16" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-12 w-12 border-b border-r border-[#D4AF37]/30 transition-all duration-500 group-hover:h-16 group-hover:w-16" />
    </div>
  );
}
