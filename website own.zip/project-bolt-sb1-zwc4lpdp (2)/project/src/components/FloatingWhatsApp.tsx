import { MessageCircle } from 'lucide-react';
import { shopConfig } from '../config';
import { buildGeneralEnquiry, buildWhatsAppUrl } from '../whatsapp';

export function FloatingWhatsApp() {
  const hasWhatsApp = shopConfig.whatsappNumber !== null;
  if (!hasWhatsApp) return null;

  return (
    <a
      href={buildWhatsAppUrl(buildGeneralEnquiry())}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-[60] flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-[#F5E6A8] to-[#D4AF37] shadow-lg shadow-[#D4AF37]/30 transition-transform hover:scale-110"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="h-7 w-7 text-black" />
      <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
        <span className="relative inline-flex h-4 w-4 rounded-full border-2 border-black bg-green-500" />
      </span>
    </a>
  );
}
