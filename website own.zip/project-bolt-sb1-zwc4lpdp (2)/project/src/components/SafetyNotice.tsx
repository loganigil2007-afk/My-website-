import { ShieldAlert, Flame, Banknote } from 'lucide-react';

export function SafetyNotice() {
  return (
    <section className="relative bg-[#0a0a0a] py-16">
      <div className="mx-auto max-w-5xl px-5 sm:px-8">
        <div className="rounded-2xl border border-[#D4AF37]/20 bg-gradient-to-b from-[#111111] to-[#080808] p-8 sm:p-10">
          <div className="flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full border border-[#D4AF37]/30 text-[#D4AF37]">
              <ShieldAlert className="h-7 w-7" />
            </div>
            <h2 className="mt-5 font-serif text-2xl font-bold text-gradient-gold sm:text-3xl">
              Safety &amp; Legal Notice
            </h2>
            <p className="mt-6 max-w-3xl text-sm leading-relaxed text-neutral-400 sm:text-base">
              Fireworks must be purchased and used in accordance with applicable
              Indian laws, local restrictions, and safety instructions. Customers
              must meet the minimum legal age requirement in their jurisdiction.
              Always follow the safety guidelines printed on each product, use
              fireworks only in designated areas, and supervise children at all times.
            </p>
            <p className="mt-4 max-w-3xl text-sm leading-relaxed text-neutral-400 sm:text-base">
              Online transactions and delivery are offered only where permitted by
              law. Where direct sales or delivery are not permitted, please use our
              enquiry system to request product and pricing information.
            </p>

            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <div className="flex items-center gap-2 rounded-full border border-[#D4AF37]/15 px-4 py-2">
                <Flame className="h-4 w-4 text-[#D4AF37]" />
                <span className="text-xs uppercase tracking-widest text-neutral-400">
                  Follow Safety Instructions
                </span>
              </div>
              <div className="flex items-center gap-2 rounded-full border border-[#D4AF37]/15 px-4 py-2">
                <Banknote className="h-4 w-4 text-[#D4AF37]" />
                <span className="text-xs uppercase tracking-widest text-neutral-400">
                  Lawful Sales Only
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
