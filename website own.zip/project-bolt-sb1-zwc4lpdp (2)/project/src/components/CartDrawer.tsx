import { X, Plus, Minus, Trash2, MessageCircle, ShoppingBag } from 'lucide-react';
import type { CartItem, Product } from '../types';
import { shopConfig } from '../config';
import { buildCartEnquiry, buildWhatsAppUrl } from '../whatsapp';

interface CartDrawerProps {
  open: boolean;
  items: CartItem[];
  products: Product[];
  onClose: () => void;
  onSetQuantity: (productId: string, quantity: number) => void;
  onRemove: (productId: string) => void;
  onClear: () => void;
}

export function CartDrawer({
  open,
  items,
  products,
  onClose,
  onSetQuantity,
  onRemove,
  onClear,
}: CartDrawerProps) {
  const hasWhatsApp = shopConfig.whatsappNumber !== null;
  const pricesConfigured = products.every((p) => p.price !== null);
  const hasItems = items.length > 0;

  const total =
    pricesConfigured && hasItems
      ? items.reduce((sum, item) => {
          const product = products.find((p) => p.id === item.productId);
          return sum + (product?.price ?? 0) * item.quantity;
        }, 0)
      : null;

  const enquiryUrl = hasWhatsApp && hasItems
    ? buildWhatsAppUrl(buildCartEnquiry(items, pricesConfigured))
    : '#';

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm transition-opacity duration-300 ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={onClose}
        aria-hidden
      />

      {/* Drawer */}
      <aside
        className={`fixed right-0 top-0 z-[80] flex h-full w-full max-w-md flex-col border-l border-[#D4AF37]/20 bg-[#080808] transition-transform duration-400 ease-out ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
        role="dialog"
        aria-label="Shopping cart"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D4AF37]/20 px-6 py-5">
          <div className="flex items-center gap-3">
            <ShoppingBag className="h-5 w-5 text-[#D4AF37]" />
            <h2 className="font-serif text-xl font-semibold text-gradient-gold">
              Your Cart
            </h2>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-[#D4AF37]/20 text-neutral-400 transition-colors hover:border-[#D4AF37] hover:text-[#F5E6A8]"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {hasItems ? (
            <ul className="space-y-4">
              {items.map((item) => (
                <li
                  key={item.productId}
                  className="rounded-xl border border-[#D4AF37]/15 bg-[#111111] p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-serif text-base font-semibold text-white">
                        {item.name}
                      </h3>
                      {products.find((p) => p.id === item.productId)?.price != null && (
                        <p className="font-display mt-1 text-sm text-[#F5E6A8]">
                          ₹{(products.find((p) => p.id === item.productId)!.price! * item.quantity).toLocaleString('en-IN')}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => onRemove(item.productId)}
                      className="text-neutral-500 transition-colors hover:text-red-400"
                      aria-label={`Remove ${item.name} from cart`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="mt-3 flex items-center gap-3">
                    <div className="flex items-center rounded-full border border-[#D4AF37]/20">
                      <button
                        onClick={() => onSetQuantity(item.productId, item.quantity - 1)}
                        className="flex h-7 w-7 items-center justify-center text-[#F5E6A8] hover:bg-[#D4AF37]/10"
                        aria-label={`Decrease ${item.name} quantity`}
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="font-display w-8 text-center text-sm font-bold text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onSetQuantity(item.productId, item.quantity + 1)}
                        className="flex h-7 w-7 items-center justify-center text-[#F5E6A8] hover:bg-[#D4AF37]/10"
                        aria-label={`Increase ${item.name} quantity`}
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <ShoppingBag className="h-12 w-12 text-[#D4AF37]/30" />
              <p className="text-sm text-neutral-500">Your cart is empty.</p>
              <p className="text-xs text-neutral-600">
                Add products from the collection to begin an enquiry.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        {hasItems && (
          <div className="border-t border-[#D4AF37]/20 px-6 py-5">
            {/* Total — only when all prices configured */}
            {total !== null ? (
              <div className="mb-4 flex items-center justify-between">
                <span className="text-sm uppercase tracking-widest text-neutral-400">
                  Total
                </span>
                <span className="font-display text-2xl font-bold text-gradient-gold">
                  ₹{total.toLocaleString('en-IN')}
                </span>
              </div>
            ) : (
              <p className="mb-4 rounded-lg border border-[#D4AF37]/15 bg-[#111111] px-4 py-3 text-xs text-neutral-400">
                Pricing will be confirmed via WhatsApp enquiry. No total is shown
                until official prices are configured.
              </p>
            )}

            <a
              href={enquiryUrl}
              target={hasWhatsApp ? '_blank' : undefined}
              rel={hasWhatsApp ? 'noopener noreferrer' : undefined}
              className={`flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient py-4 text-sm font-bold uppercase tracking-widest text-black transition-all hover:gold-glow-strong ${
                !hasWhatsApp ? 'pointer-events-none opacity-40' : ''
              }`}
            >
              <MessageCircle className="h-5 w-5" />
              {pricesConfigured ? 'Send Order Enquiry' : 'Request Price Quotation'}
            </a>

            {!hasWhatsApp && (
              <p className="mt-3 text-center text-xs text-neutral-500">
                WhatsApp will be available once the shop number is configured.
              </p>
            )}

            <button
              onClick={onClear}
              className="mt-3 w-full text-center text-xs uppercase tracking-widest text-neutral-500 transition-colors hover:text-red-400"
            >
              Clear Cart
            </button>
          </div>
        )}
      </aside>
    </>
  );
}
