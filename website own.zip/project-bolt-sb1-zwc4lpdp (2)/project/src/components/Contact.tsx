import { Instagram, MessageCircle, Phone, ArrowUpRight } from 'lucide-react';
import { shopConfig } from '../config';
import { buildGeneralEnquiry, buildWhatsAppUrl } from '../whatsapp';

interface ContactCardProps {
  icon: React.ReactNode;
  eyebrow: string;
  title: string;
  detail: string;
  children: React.ReactNode;
  iconClassName?: string;
}

function ContactCard({
  icon,
  eyebrow,
  title,
  detail,
  children,
  iconClassName = 'text-[#D4AF37]',
}: ContactCardProps) {
  return (
    <article className="group relative flex flex-col rounded-2xl border border-[#D4AF37]/20 bg-[#111111] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[#D4AF37]/55 hover:bg-[#151515] sm:p-7">
      <div className={`flex h-12 w-12 items-center justify-center rounded-full border border-[#D4AF37]/30 ${iconClassName}`}>
        {icon}
      </div>
      <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.28em] text-[#D4AF37]">
        {eyebrow}
      </p>
      <h3 className="font-display mt-2 text-2xl font-bold tracking-wide text-[#F5E6A8]">{title}</h3>
      <p className="mt-2 min-h-12 text-sm leading-relaxed text-neutral-400">{detail}</p>
      <div className="mt-6">{children}</div>
      <div className="pointer-events-none absolute right-0 top-0 h-14 w-14 border-r border-t border-[#D4AF37]/20 transition-all duration-300 group-hover:h-20 group-hover:w-20" />
    </article>
  );
}

const actionClassName =
  'flex w-full items-center justify-center gap-2 rounded-full border border-[#D4AF37]/35 px-4 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#F5E6A8] transition-all hover:border-[#D4AF37] hover:bg-[#D4AF37]/10';

export function Contact() {
  const whatsappUrl = buildWhatsAppUrl(buildGeneralEnquiry());

  return (
    <section id="contact" className="relative overflow-hidden bg-[#080808] py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-1/3 h-[300px] w-[400px] rounded-full bg-[#D4AF37]/5 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">
            Get in Touch
          </p>
          <h2 className="font-serif text-3xl font-bold text-gradient-gold sm:text-4xl md:text-5xl">
            GET IN TOUCH WITH ORCA'S
          </h2>
          <div className="mx-auto mt-6 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-[#D4AF37]" />
            <span className="h-1.5 w-1.5 rotate-45 bg-[#D4AF37]" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-[#D4AF37]" />
          </div>
          <p className="mt-6 text-sm leading-relaxed text-neutral-400 sm:text-base">
            We're here to help. Contact ORCA'S for product enquiries and celebration collection information.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <ContactCard
            icon={<Phone className="h-5 w-5" />}
            eyebrow="Call Us — Primary"
            title={shopConfig.phone ?? ''}
            detail="Speak with our team about products, availability, and celebration enquiries."
          >
            <a href={`tel:${shopConfig.phone}`} className={actionClassName}>
              Call Now <ArrowUpRight className="h-4 w-4" />
            </a>
          </ContactCard>

          <ContactCard
            icon={<Phone className="h-5 w-5" />}
            eyebrow="Call Us — Secondary"
            title={shopConfig.secondaryPhone ?? ''}
            detail="Reach our secondary line for product questions and collection information."
          >
            <a href={`tel:${shopConfig.secondaryPhone}`} className={actionClassName}>
              Call Secondary Number <ArrowUpRight className="h-4 w-4" />
            </a>
          </ContactCard>

          <ContactCard
            icon={<MessageCircle className="h-5 w-5" />}
            iconClassName="border-green-500/40 text-[#25D366]"
            eyebrow="WhatsApp Enquiries"
            title="CHAT WITH US"
            detail="Send us a message for product details, pricing, and availability."
          >
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-xs font-bold uppercase tracking-[0.12em] text-black transition-all hover:bg-[#49e483] hover:shadow-[0_0_20px_rgba(37,211,102,0.2)]"
            >
              <MessageCircle className="h-4 w-4" />
              Chat With Us On WhatsApp
            </a>
          </ContactCard>
        </div>

        <div className="mt-5 flex justify-center">
          <a
            href={shopConfig.instagram ?? '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex w-full max-w-sm items-center justify-center gap-3 rounded-2xl border border-[#D4AF37]/20 bg-[#111111] px-6 py-5 transition-all hover:border-[#D4AF37]/55 hover:bg-[#151515]"
          >
            <Instagram className="h-6 w-6 text-[#F5E6A8] transition-colors group-hover:text-[#D4AF37]" />
            <span className="text-sm font-semibold uppercase tracking-[0.14em] text-[#F5E6A8]">
              @orcasbrand
            </span>
            <ArrowUpRight className="h-4 w-4 text-[#D4AF37]" />
          </a>
        </div>
      </div>
    </section>
  );
}
