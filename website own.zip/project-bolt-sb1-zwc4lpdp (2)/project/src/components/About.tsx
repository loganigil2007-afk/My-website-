import { Sparkles, Flame } from 'lucide-react';
import { Particles } from './Particles';
import { aboutImage, shopConfig } from '../config';

export function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-[#0a0a0a] py-24 sm:py-32">
      <Particles count={15} />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Image */}
          <div className="relative order-2 lg:order-1">
            <div className="relative overflow-hidden rounded-2xl border border-[#D4AF37]/20">
              <img
                src={aboutImage}
                alt="Golden fireworks celebration"
                className="aspect-[4/3] w-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>
            {/* Decorative frame */}
            <div className="pointer-events-none absolute -inset-3 -z-10 rounded-3xl border border-[#D4AF37]/10" />
            <div className="pointer-events-none absolute -bottom-4 -right-4 h-24 w-24 rounded-full bg-[#D4AF37]/10 blur-2xl" />
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2">
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">
              About {shopConfig.brandName}
            </p>
            <h2 className="font-serif text-3xl font-bold leading-tight text-gradient-gold sm:text-4xl md:text-5xl">
              CELEBRATING BRILLIANCE.
              <br />
              CREATING MEMORIES.
            </h2>
            <div className="mt-6 flex items-center gap-3">
              <span className="h-px w-16 bg-gradient-to-r from-[#D4AF37] to-transparent" />
              <Flame className="h-4 w-4 text-[#D4AF37]" />
            </div>

            <div className="mt-8 space-y-5 text-neutral-400">
              <p className="leading-relaxed">
                {shopConfig.brandName} Fireworks is dedicated to making every
                celebration unforgettable. Our signature Garland Collection brings
                grandeur to your festivities, whether it's a festival, a wedding,
                or a cherished family gathering.
              </p>
              <p className="leading-relaxed">
                We believe in helping you choose the right fireworks for the right
                moment. Every enquiry is handled with personal attention — from
                guiding you through our collection to sharing pricing, availability,
                and safe usage instructions.
              </p>
              <p className="leading-relaxed">
                Reach out to us anytime. We're here to make your celebrations
                iconic.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <div className="flex items-center gap-2 rounded-full border border-[#D4AF37]/20 px-4 py-2">
                <Sparkles className="h-4 w-4 text-[#D4AF37]" />
                <span className="text-xs uppercase tracking-widest text-neutral-300">
                  Personal Enquiries
                </span>
              </div>
              <div className="flex items-center gap-2 rounded-full border border-[#D4AF37]/20 px-4 py-2">
                <Flame className="h-4 w-4 text-[#D4AF37]" />
                <span className="text-xs uppercase tracking-widest text-neutral-300">
                  Premium Quality
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
