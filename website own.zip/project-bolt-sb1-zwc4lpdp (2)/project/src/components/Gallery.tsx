import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, X } from 'lucide-react';
import galleryStack from '../assets/gallery/file_00000000e330820bb58e7c399bf7684b.png';
import galleryTwoK from '../assets/gallery/IMG-20261020-WA0059.jpg';
import galleryFiveK from '../assets/gallery/IMG-20261020-WA0060.jpg';
import galleryTenK from '../assets/gallery/motion_photo_7578446050472871929.jpg';

const galleryImages = [
  { src: galleryStack, alt: "ORCA'S 1K fireworks collection display", label: '1K Collection' },
  { src: galleryTwoK, alt: "ORCA'S 2K Kings Indian fireworks box", label: '2K Collection' },
  { src: galleryFiveK, alt: "ORCA'S 5K Kings Indian fireworks box", label: '5K Collection' },
  { src: galleryTenK, alt: "ORCA'S 10K celebration fireworks box", label: '10K Collection' },
];

export function Gallery() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const closeViewer = () => setActiveIndex(null);
  const showPrevious = () => setActiveIndex((current) => current === null ? null : (current - 1 + galleryImages.length) % galleryImages.length);
  const showNext = () => setActiveIndex((current) => current === null ? null : (current + 1) % galleryImages.length);

  useEffect(() => {
    if (activeIndex === null) return undefined;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeViewer();
      if (event.key === 'ArrowLeft') showPrevious();
      if (event.key === 'ArrowRight') showNext();
    };

    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [activeIndex]);

  return (
    <section id="gallery" className="relative overflow-hidden bg-[#080808] py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-1/4 h-[320px] w-[420px] rounded-full bg-[#D4AF37]/5 blur-[110px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.4em] text-[#D4AF37]">The ORCA'S Collection</p>
          <h2 className="font-serif text-3xl font-bold text-gradient-gold sm:text-4xl md:text-5xl">PRODUCT GALLERY</h2>
          <div className="mx-auto mt-6 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-[#D4AF37]" />
            <span className="h-1.5 w-1.5 rotate-45 bg-[#D4AF37]" />
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-[#D4AF37]" />
          </div>
          <p className="mt-6 text-sm leading-relaxed text-neutral-400 sm:text-base">
            Explore a closer look at the celebration collections crafted for memorable moments.
          </p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {galleryImages.map((image, index) => (
            <button
              key={image.src}
              type="button"
              onClick={() => setActiveIndex(index)}
              className="group relative overflow-hidden rounded-2xl border border-[#D4AF37]/20 bg-[#111111] p-2 text-left shadow-[0_12px_35px_rgba(0,0,0,0.3)] transition-all duration-300 hover:-translate-y-1 hover:border-[#D4AF37]/60 hover:shadow-[0_18px_45px_rgba(212,175,55,0.12)]"
              aria-label={`View ${image.label} image`}
            >
              <div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden rounded-xl bg-black">
                <img
                  src={image.src}
                  alt={image.alt}
                  loading={index === 0 ? 'eager' : 'lazy'}
                  className="h-full w-full object-contain transition-transform duration-500 group-hover:scale-[1.03]"
                />
                <span className="absolute bottom-3 right-3 flex h-9 w-9 items-center justify-center rounded-full border border-[#F5E6A8]/40 bg-black/70 text-[#F5E6A8] opacity-0 backdrop-blur-sm transition-opacity duration-300 group-hover:opacity-100">
                  <Maximize2 className="h-4 w-4" />
                </span>
              </div>
              <div className="flex items-center justify-between px-2 pb-2 pt-4">
                <span className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-[#F5E6A8]">{image.label}</span>
                <span className="h-px w-8 bg-[#D4AF37]/40 transition-all duration-300 group-hover:w-12 group-hover:bg-[#D4AF37]" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {activeIndex !== null && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/95 p-4 backdrop-blur-sm sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={`${galleryImages[activeIndex].label} enlarged image`}
          onClick={closeViewer}
        >
          <button
            type="button"
            onClick={closeViewer}
            className="absolute right-4 top-4 z-10 flex h-11 w-11 items-center justify-center rounded-full border border-[#D4AF37]/40 bg-[#111111] text-[#F5E6A8] transition-colors hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 sm:right-8 sm:top-8"
            aria-label="Close image viewer"
          >
            <X className="h-5 w-5" />
          </button>

          <button
            type="button"
            onClick={(event) => { event.stopPropagation(); showPrevious(); }}
            className="absolute left-3 top-1/2 z-10 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-[#D4AF37]/40 bg-[#111111]/90 text-[#F5E6A8] transition-colors hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 sm:left-8"
            aria-label="Previous gallery image"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <img
            src={galleryImages[activeIndex].src}
            alt={galleryImages[activeIndex].alt}
            className="max-h-[88vh] max-w-[calc(100vw-6rem)] object-contain sm:max-w-[calc(100vw-12rem)]"
            onClick={(event) => event.stopPropagation()}
          />

          <button
            type="button"
            onClick={(event) => { event.stopPropagation(); showNext(); }}
            className="absolute right-3 top-1/2 z-10 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-[#D4AF37]/40 bg-[#111111]/90 text-[#F5E6A8] transition-colors hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 sm:right-8"
            aria-label="Next gallery image"
          >
            <ChevronRight className="h-5 w-5" />
          </button>

          <p className="absolute bottom-5 left-1/2 -translate-x-1/2 font-display text-sm uppercase tracking-[0.2em] text-[#F5E6A8] sm:bottom-8">
            {galleryImages[activeIndex].label}
          </p>
        </div>
      )}
    </section>
  );
}
