import { Sparkles } from 'lucide-react';
import { shopConfig } from '../config';

export function AnnouncementBar() {
  if (!shopConfig.announcement) return null;
  return (
    <div className="relative z-[60] overflow-hidden border-b border-[#D4AF37]/20 bg-black">
      <div className="animate-shimmer flex items-center justify-center gap-2 py-2 text-center">
        <Sparkles className="h-3.5 w-3.5 text-[#D4AF37]" />
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#F5E6A8]">
          {shopConfig.announcement}
        </p>
        <Sparkles className="h-3.5 w-3.5 text-[#D4AF37]" />
      </div>
    </div>
  );
}
