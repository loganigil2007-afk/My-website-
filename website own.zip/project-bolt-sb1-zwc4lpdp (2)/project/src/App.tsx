import { useState } from 'react';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Collection } from './components/Collection';
import { Gallery } from './components/Gallery';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { SafetyNotice } from './components/SafetyNotice';
import { CustomDomain } from './components/CustomDomain';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { CartDrawer } from './components/CartDrawer';
import { products } from './config';
import { useCart } from './useCart';

function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const cart = useCart();

  return (
    <div className="min-h-screen bg-[#080808] text-neutral-100">
      <AnnouncementBar />
      <Navbar cartCount={cart.count} onCartClick={() => setCartOpen(true)} />

      <main>
        <Hero />
        <Collection products={products} onAddToCart={cart.addItem} />
        <Gallery />
        <About />
        <Contact />
        <CustomDomain />
        <SafetyNotice />
      </main>

      <Footer />
      <FloatingWhatsApp />
      <CartDrawer
        open={cartOpen}
        items={cart.items}
        products={products}
        onClose={() => setCartOpen(false)}
        onSetQuantity={cart.setQuantity}
        onRemove={cart.removeItem}
        onClear={cart.clear}
      />
    </div>
  );
}

export default App;
